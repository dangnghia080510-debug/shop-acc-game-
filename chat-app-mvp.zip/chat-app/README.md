# Chat App - Giai đoạn 1 (MVP)

Ứng dụng nhắn tin realtime giống Messenger / Zalo cơ bản.

## Tính năng đã có

- Đăng ký / Đăng nhập (Email + Password và Google)
- Chat realtime 1-1
- Gửi tin nhắn text
- Gửi ảnh, video, file (tối đa 20MB)
- Trang cá nhân (đổi tên, bio, ảnh đại diện)
- Danh sách cuộc trò chuyện + tìm kiếm người dùng
- Giao diện tiếng Việt, responsive cơ bản

## Cách chạy

### 1. Cài đặt

```bash
cd chat-app
npm install
```

### 2. Cấu hình Firebase

1. Vào https://console.firebase.google.com → tạo project mới
2. **Authentication** → Sign-in method → bật:
   - Email/Password
   - Google
3. **Firestore Database** → Create database → chế độ **Test mode** (hoặc Production + rule phù hợp)
4. **Storage** → Get started → chế độ Test mode
5. Project settings → Your apps → Web → copy config
6. Dán vào file `src/firebase/config.js`

### 3. Chạy local

```bash
npm run dev
```

Mở http://localhost:5173

## Cấu trúc thư mục

```
src/
├── components/
│   ├── ChatWindow.jsx   # Cửa sổ chat + gửi media
│   ├── Sidebar.jsx      # Danh sách chat + người dùng
│   └── Profile.jsx      # Trang cá nhân
├── contexts/
│   └── AuthContext.jsx  # Quản lý đăng nhập
├── firebase/
│   └── config.js        # Cấu hình Firebase
├── pages/
│   ├── Home.jsx
│   ├── Login.jsx
│   └── Register.jsx
├── styles/
│   └── global.css
└── App.jsx
```

## Lưu ý quan trọng

- Firestore & Storage đang ở **Test mode** → chỉ dùng để demo. Khi lên production phải viết Security Rules.
- Gọi thoại/video sẽ làm ở **Giai đoạn 2**.
- Nhóm chat, thông báo, tin nhắn đã xem... sẽ làm sau.

## Bước tiếp theo (Giai đoạn 2)

- Gọi thoại / video (WebRTC hoặc Agora)
- Nhóm chat
- Trạng thái online/offline
- Thông báo đẩy
- Admin quản lý người dùng
