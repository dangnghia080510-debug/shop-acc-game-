// =====================================================
// CẤU HÌNH FIREBASE
// =====================================================
// 1. Vào https://console.firebase.google.com
// 2. Tạo project mới
// 3. Bật Authentication → Email/Password + Google
// 4. Tạo Firestore Database (mode test)
// 5. Bật Storage
// 6. Copy config vào đây

import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
export default app;
