import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import {
  collection,
  query,
  where,
  onSnapshot,
  orderBy,
  doc,
  getDoc,
  setDoc,
  serverTimestamp,
} from "firebase/firestore";
import { db } from "../firebase/config";
import Sidebar from "../components/Sidebar";
import ChatWindow from "../components/ChatWindow";
import Profile from "../components/Profile";

export default function Home() {
  const { currentUser, logout } = useAuth();
  const [chats, setChats] = useState([]);
  const [selectedChat, setSelectedChat] = useState(null);
  const [showProfile, setShowProfile] = useState(false);
  const [allUsers, setAllUsers] = useState([]);
  const navigate = useNavigate();

  // Lấy danh sách chat của user hiện tại
  useEffect(() => {
    if (!currentUser) return;

    const q = query(
      collection(db, "chats"),
      where("members", "array-contains", currentUser.uid)
    );

    const unsubscribe = onSnapshot(q, async (snapshot) => {
      const chatList = [];

      for (const docSnap of snapshot.docs) {
        const data = docSnap.data();
        // Lấy thông tin người còn lại
        const otherUid = data.members.find((id) => id !== currentUser.uid);
        let otherUser = { displayName: "Người dùng", photoURL: "" };

        if (otherUid) {
          const userSnap = await getDoc(doc(db, "users", otherUid));
          if (userSnap.exists()) {
            otherUser = userSnap.data();
          }
        }

        chatList.push({
          id: docSnap.id,
          ...data,
          otherUser,
        });
      }

      // Sắp xếp theo thời gian tin nhắn cuối
      chatList.sort((a, b) => {
        const timeA = a.lastMessageAt?.toMillis?.() || 0;
        const timeB = b.lastMessageAt?.toMillis?.() || 0;
        return timeB - timeA;
      });

      setChats(chatList);
    });

    return unsubscribe;
  }, [currentUser]);

  // Lấy danh sách tất cả users (để bắt đầu chat mới)
  useEffect(() => {
    if (!currentUser) return;

    const q = query(collection(db, "users"));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const users = snapshot.docs
        .map((d) => ({ id: d.id, ...d.data() }))
        .filter((u) => u.uid !== currentUser.uid);
      setAllUsers(users);
    });

    return unsubscribe;
  }, [currentUser]);

  // Tạo hoặc mở chat với một user
  async function startChat(otherUser) {
    // Tìm xem đã có chat chưa
    const existing = chats.find(
      (c) =>
        c.members.includes(otherUser.uid) &&
        c.members.includes(currentUser.uid)
    );

    if (existing) {
      setSelectedChat(existing);
      setShowProfile(false);
      return;
    }

    // Tạo chat mới
    const chatId = [currentUser.uid, otherUser.uid].sort().join("_");
    const chatRef = doc(db, "chats", chatId);

    await setDoc(chatRef, {
      members: [currentUser.uid, otherUser.uid],
      createdAt: serverTimestamp(),
      lastMessage: "",
      lastMessageAt: serverTimestamp(),
    });

    setSelectedChat({
      id: chatId,
      members: [currentUser.uid, otherUser.uid],
      otherUser,
    });
    setShowProfile(false);
  }

  async function handleLogout() {
    await logout();
    navigate("/login");
  }

  return (
    <div className="app-layout">
      <Sidebar
        chats={chats}
        allUsers={allUsers}
        selectedChat={selectedChat}
        onSelectChat={(chat) => {
          setSelectedChat(chat);
          setShowProfile(false);
        }}
        onStartChat={startChat}
        onShowProfile={() => {
          setShowProfile(true);
          setSelectedChat(null);
        }}
        onLogout={handleLogout}
        currentUser={currentUser}
      />

      <main className="main-content">
        {showProfile ? (
          <Profile />
        ) : selectedChat ? (
          <ChatWindow chat={selectedChat} currentUser={currentUser} />
        ) : (
          <div className="empty-state">
            <h2>Chào mừng đến Chat App</h2>
            <p>Chọn một cuộc trò chuyện hoặc tìm người để bắt đầu nhắn tin</p>
          </div>
        )}
      </main>
    </div>
  );
}
