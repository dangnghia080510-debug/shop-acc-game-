import { useState, useEffect, useRef } from "react";
import {
  collection,
  query,
  orderBy,
  onSnapshot,
  addDoc,
  updateDoc,
  doc,
  serverTimestamp,
} from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { db, storage } from "../firebase/config";

export default function ChatWindow({ chat, currentUser }) {
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState("");
  const [uploading, setUploading] = useState(false);
  const bottomRef = useRef(null);
  const fileInputRef = useRef(null);

  // Lắng nghe tin nhắn realtime
  useEffect(() => {
    if (!chat?.id) return;

    const q = query(
      collection(db, "chats", chat.id, "messages"),
      orderBy("createdAt", "asc")
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const msgs = snapshot.docs.map((d) => ({
        id: d.id,
        ...d.data(),
      }));
      setMessages(msgs);
    });

    return unsubscribe;
  }, [chat?.id]);

  // Tự cuộn xuống cuối
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Gửi tin nhắn text
  async function sendMessage(e) {
    e.preventDefault();
    if (!text.trim()) return;

    const messageText = text.trim();
    setText("");

    await addDoc(collection(db, "chats", chat.id, "messages"), {
      text: messageText,
      senderId: currentUser.uid,
      type: "text",
      createdAt: serverTimestamp(),
    });

    // Cập nhật lastMessage của chat
    await updateDoc(doc(db, "chats", chat.id), {
      lastMessage: messageText,
      lastMessageAt: serverTimestamp(),
    });
  }

  // Gửi file / ảnh / video
  async function handleFileSelect(e) {
    const file = e.target.files[0];
    if (!file) return;

    // Giới hạn 20MB
    if (file.size > 20 * 1024 * 1024) {
      alert("File quá lớn (tối đa 20MB)");
      return;
    }

    setUploading(true);

    try {
      const storageRef = ref(
        storage,
        `chats/${chat.id}/${Date.now()}_${file.name}`
      );
      await uploadBytes(storageRef, file);
      const url = await getDownloadURL(storageRef);

      let type = "file";
      if (file.type.startsWith("image/")) type = "image";
      else if (file.type.startsWith("video/")) type = "video";

      await addDoc(collection(db, "chats", chat.id, "messages"), {
        text: file.name,
        fileUrl: url,
        fileName: file.name,
        fileType: file.type,
        senderId: currentUser.uid,
        type,
        createdAt: serverTimestamp(),
      });

      await updateDoc(doc(db, "chats", chat.id), {
        lastMessage: type === "image" ? "📷 Ảnh" : type === "video" ? "🎥 Video" : "📎 File",
        lastMessageAt: serverTimestamp(),
      });
    } catch (err) {
      console.error(err);
      alert("Gửi file thất bại");
    }

    setUploading(false);
    e.target.value = "";
  }

  function formatTime(timestamp) {
    if (!timestamp?.toDate) return "";
    const date = timestamp.toDate();
    return date.toLocaleTimeString("vi-VN", {
      hour: "2-digit",
      minute: "2-digit",
    });
  }

  return (
    <div className="chat-window">
      {/* Header */}
      <div className="chat-header">
        <div className="avatar">
          {chat.otherUser?.photoURL ? (
            <img src={chat.otherUser.photoURL} alt="" />
          ) : (
            <span>
              {chat.otherUser?.displayName?.charAt(0)?.toUpperCase() || "U"}
            </span>
          )}
        </div>
        <div>
          <strong>{chat.otherUser?.displayName || "Người dùng"}</strong>
          <small>Online</small>
        </div>
      </div>

      {/* Messages */}
      <div className="messages">
        {messages.map((msg) => {
          const isMine = msg.senderId === currentUser.uid;
          return (
            <div
              key={msg.id}
              className={`message ${isMine ? "mine" : "theirs"}`}
            >
              {msg.type === "text" && <p>{msg.text}</p>}

              {msg.type === "image" && (
                <a href={msg.fileUrl} target="_blank" rel="noreferrer">
                  <img src={msg.fileUrl} alt="Ảnh" className="msg-image" />
                </a>
              )}

              {msg.type === "video" && (
                <video controls className="msg-video">
                  <source src={msg.fileUrl} type={msg.fileType} />
                </video>
              )}

              {msg.type === "file" && (
                <a
                  href={msg.fileUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="msg-file"
                >
                  📎 {msg.fileName}
                </a>
              )}

              <span className="time">{formatTime(msg.createdAt)}</span>
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <form className="chat-input" onSubmit={sendMessage}>
        <button
          type="button"
          className="btn-icon"
          onClick={() => fileInputRef.current?.click()}
          disabled={uploading}
          title="Gửi ảnh / video / file"
        >
          {uploading ? "⏳" : "📎"}
        </button>
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileSelect}
          accept="image/*,video/*,.pdf,.doc,.docx,.xls,.xlsx,.zip,.rar"
          hidden
        />

        <input
          type="text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Nhập tin nhắn..."
          disabled={uploading}
        />

        <button type="submit" className="btn-send" disabled={!text.trim() || uploading}>
          Gửi
        </button>
      </form>
    </div>
  );
}
