import { useState } from "react";

export default function Sidebar({
  chats,
  allUsers,
  selectedChat,
  onSelectChat,
  onStartChat,
  onShowProfile,
  onLogout,
  currentUser,
}) {
  const [search, setSearch] = useState("");
  const [showUsers, setShowUsers] = useState(false);

  const filteredChats = chats.filter((c) =>
    c.otherUser?.displayName?.toLowerCase().includes(search.toLowerCase())
  );

  const filteredUsers = allUsers.filter((u) =>
    u.displayName?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <aside className="sidebar">
      {/* Header */}
      <div className="sidebar-header">
        <div className="user-info" onClick={onShowProfile}>
          <div className="avatar">
            {currentUser?.photoURL ? (
              <img src={currentUser.photoURL} alt="" />
            ) : (
              <span>
                {currentUser?.displayName?.charAt(0)?.toUpperCase() || "U"}
              </span>
            )}
          </div>
          <div>
            <strong>{currentUser?.displayName || "Người dùng"}</strong>
            <small>Xem trang cá nhân</small>
          </div>
        </div>
        <button className="btn-icon" onClick={onLogout} title="Đăng xuất">
          ⎋
        </button>
      </div>

      {/* Search */}
      <div className="search-box">
        <input
          type="text"
          placeholder="Tìm kiếm..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {/* Tabs */}
      <div className="tabs">
        <button
          className={!showUsers ? "active" : ""}
          onClick={() => setShowUsers(false)}
        >
          Tin nhắn
        </button>
        <button
          className={showUsers ? "active" : ""}
          onClick={() => setShowUsers(true)}
        >
          Mọi người
        </button>
      </div>

      {/* List */}
      <div className="chat-list">
        {!showUsers ? (
          filteredChats.length === 0 ? (
            <p className="empty-list">Chưa có cuộc trò chuyện nào</p>
          ) : (
            filteredChats.map((chat) => (
              <div
                key={chat.id}
                className={`chat-item ${
                  selectedChat?.id === chat.id ? "active" : ""
                }`}
                onClick={() => onSelectChat(chat)}
              >
                <div className="avatar">
                  {chat.otherUser?.photoURL ? (
                    <img src={chat.otherUser.photoURL} alt="" />
                  ) : (
                    <span>
                      {chat.otherUser?.displayName?.charAt(0)?.toUpperCase() ||
                        "U"}
                    </span>
                  )}
                </div>
                <div className="chat-info">
                  <strong>{chat.otherUser?.displayName || "Người dùng"}</strong>
                  <p className="last-msg">{chat.lastMessage || "Bắt đầu chat"}</p>
                </div>
              </div>
            ))
          )
        ) : (
          filteredUsers.map((user) => (
            <div
              key={user.uid}
              className="chat-item"
              onClick={() => onStartChat(user)}
            >
              <div className="avatar">
                {user.photoURL ? (
                  <img src={user.photoURL} alt="" />
                ) : (
                  <span>{user.displayName?.charAt(0)?.toUpperCase() || "U"}</span>
                )}
              </div>
              <div className="chat-info">
                <strong>{user.displayName}</strong>
                <p className="last-msg">{user.bio || "Nhấn để nhắn tin"}</p>
              </div>
            </div>
          ))
        )}
      </div>
    </aside>
  );
}
