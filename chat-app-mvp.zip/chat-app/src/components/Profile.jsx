import { useState, useEffect } from "react";
import { useAuth } from "../contexts/AuthContext";
import { doc, updateDoc } from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { updateProfile } from "firebase/auth";
import { db, storage, auth } from "../firebase/config";

export default function Profile() {
  const { currentUser, userProfile } = useAuth();
  const [displayName, setDisplayName] = useState("");
  const [bio, setBio] = useState("");
  const [photoURL, setPhotoURL] = useState("");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (userProfile) {
      setDisplayName(userProfile.displayName || "");
      setBio(userProfile.bio || "");
      setPhotoURL(userProfile.photoURL || "");
    }
  }, [userProfile]);

  async function handlePhotoChange(e) {
    const file = e.target.files[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      alert("Chỉ chọn file ảnh");
      return;
    }

    setLoading(true);
    try {
      const storageRef = ref(storage, `avatars/${currentUser.uid}`);
      await uploadBytes(storageRef, file);
      const url = await getDownloadURL(storageRef);

      await updateProfile(auth.currentUser, { photoURL: url });
      await updateDoc(doc(db, "users", currentUser.uid), { photoURL: url });

      setPhotoURL(url);
      setMessage("Cập nhật ảnh thành công!");
    } catch (err) {
      console.error(err);
      alert("Upload ảnh thất bại");
    }
    setLoading(false);
  }

  async function handleSave(e) {
    e.preventDefault();
    setLoading(true);
    setMessage("");

    try {
      await updateProfile(auth.currentUser, { displayName });
      await updateDoc(doc(db, "users", currentUser.uid), {
        displayName,
        bio,
      });
      setMessage("Lưu thành công!");
    } catch (err) {
      console.error(err);
      setMessage("Có lỗi xảy ra");
    }
    setLoading(false);
  }

  return (
    <div className="profile-page">
      <h2>Trang cá nhân</h2>

      <div className="profile-card">
        <div className="avatar-large">
          {photoURL ? (
            <img src={photoURL} alt="Avatar" />
          ) : (
            <span>{displayName?.charAt(0)?.toUpperCase() || "U"}</span>
          )}
        </div>

        <label className="btn-change-photo">
          Đổi ảnh đại diện
          <input
            type="file"
            accept="image/*"
            onChange={handlePhotoChange}
            hidden
            disabled={loading}
          />
        </label>

        <form onSubmit={handleSave}>
          <div className="form-group">
            <label>Tên hiển thị</label>
            <input
              type="text"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label>Email</label>
            <input type="email" value={currentUser?.email || ""} disabled />
          </div>

          <div className="form-group">
            <label>Giới thiệu</label>
            <textarea
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              rows={3}
              placeholder="Viết vài dòng về bản thân..."
            />
          </div>

          {message && <div className="success-box">{message}</div>}

          <button type="submit" className="btn-primary" disabled={loading}>
            {loading ? "Đang lưu..." : "Lưu thay đổi"}
          </button>
        </form>
      </div>
    </div>
  );
}
